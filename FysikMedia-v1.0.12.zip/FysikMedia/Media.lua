local _ = ... -- Internal namespace
local LSM = LibStub("LibSharedMedia-3.0")
FysikMedia = {}
LSM:Register("font","Expressway", [[Interface\Addons\NorthernSkyRaidTools\Media\Fonts\Expressway.TTF]])
--StatusBars
LSM:Register("statusbar","Atrocity", [[Interface\Addons\NorthernSkyRaidTools\Media\StatusBars\Atrocity]])
-- Open WA Options
function FysikMedia.OpenWA()
    print("hampusdid911")
end

FysikMedia.BreakMemes = {
        {[[Interface\AddOns\FysikMedia\Memes\daitosus.png]], 384, 366},
        {[[Interface\AddOns\FysikMedia\Memes\draganecandy.png]], 384, 405},
        {[[Interface\AddOns\FysikMedia\Memes\draganehello.png]], 384, 405},
        {[[Interface\AddOns\FysikMedia\Memes\draganemarkus.png]], 384, 405},
        {[[Interface\AddOns\FysikMedia\Memes\draganepoop.png]], 384, 405},
        {[[Interface\AddOns\FysikMedia\Memes\draganetish.png]], 384, 405},
        {[[Interface\AddOns\FysikMedia\Memes\draganewtf.png]], 384, 405},
        {[[Interface\AddOns\FysikMedia\Memes\eggwa.png]], 384, 534},
        {[[Interface\AddOns\FysikMedia\Memes\fknlatoss.png]], 384, 682},
        {[[Interface\AddOns\FysikMedia\Memes\guffyass.png]], 384, 514},
        {[[Interface\AddOns\FysikMedia\Memes\kazandsheb.png]], 384, 102},
        {[[Interface\AddOns\FysikMedia\Memes\kazmilbeard.png]], 384, 274},
        {[[Interface\AddOns\FysikMedia\Memes\kazmilcat.png]], 384, 325},
        {[[Interface\AddOns\FysikMedia\Memes\kazmilcope.png]], 384, 429},
        {[[Interface\AddOns\FysikMedia\Memes\kazmildrunk.png]], 384, 514},
        {[[Interface\AddOns\FysikMedia\Memes\kazmilgirls.png]], 384, 393},
        {[[Interface\AddOns\FysikMedia\Memes\kazmiltitanic.png]], 384, 285},
        {[[Interface\AddOns\FysikMedia\Memes\kylgequest.png]], 384, 249},
        {[[Interface\AddOns\FysikMedia\Memes\whoraclemicdown.png]], 384, 249},
        {[[Interface\AddOns\FysikMedia\Memes\gaffymage.png]], 384, 486},
        {[[Interface\AddOns\FysikMedia\Memes\postburgersadness.jpg]], 384, 682},
        {[[Interface\AddOns\FysikMedia\Memes\draganesleep.png]], 384, 343},
        {[[Interface\AddOns\FysikMedia\Memes\antdate.jpg]], 384, 514},
        {[[Interface\AddOns\FysikMedia\Memes\antmirror.jpg]], 384, 512},
        {[[Interface\AddOns\FysikMedia\Memes\draganebaby.jpg]], 384, 512},
        {[[Interface\AddOns\FysikMedia\Memes\draganeburger.png]], 384, 479},
        {[[Interface\AddOns\FysikMedia\Memes\draganeglasses.jpg]], 384, 682},
        {[[Interface\AddOns\FysikMedia\Memes\draganekid.png]], 384, 519},
        {[[Interface\AddOns\FysikMedia\Memes\draganemirror.jpg]], 384, 682},
        {[[Interface\AddOns\FysikMedia\Memes\draganerave.png]], 384, 831},
        {[[Interface\AddOns\FysikMedia\Memes\weecepiano.png]], 384, 362},
        {[[Interface\AddOns\FysikMedia\Memes\daitotoilet.png]], 384, 384},
        {[[Interface\AddOns\FysikMedia\Memes\tishcat.png]], 384, 515},
        {[[Interface\AddOns\FysikMedia\Memes\antdrunk.png]], 384, 513},
        {[[Interface\AddOns\FysikMedia\Memes\fibbo.png]], 384, 384},
        {[[Interface\AddOns\FysikMedia\Memes\tishcamp.png]], 384, 384},
        {[[Interface\AddOns\FysikMedia\Memes\waackocool.png]], 384, 540},
        {[[Interface\AddOns\FysikMedia\Memes\waackomilitary.png]], 384, 494},
        {[[Interface\AddOns\FysikMedia\Memes\waackostrong.png]], 384, 355},
        }