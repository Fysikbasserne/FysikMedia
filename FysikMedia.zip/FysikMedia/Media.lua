local _ = ... -- Internal namespace
local LSM = LibStub("LibSharedMedia-3.0")
FysikMedia = {}
LSM:Register("font","Expressway", [[Interface\Addons\NorthernSkyRaidTools\Media\Fonts\Expressway.TTF]])
--StatusBars
LSM:Register("statusbar","Atrocity", [[Interface\Addons\NorthernSkyRaidTools\Media\StatusBars\Atrocity]])
-- Open WA Options
function FysikMedia.OpenWA()
    print("hampusdid911")
end

-- Memes for Break-Timer
FysikMedia.BreakMemes = {
        -- [[Interface\AddOns\NorthernSkyRaidTools\Media\Memes\ZarugarPeace.blp]], 256, 256},
        -- {[[Interface\AddOns\NorthernSkyRaidTools\Media\Memes\ZarugarChad.blp]], 256, 147},
        -- {[[Interface\AddOns\NorthernSkyRaidTools\Media\Memes\Overtime.blp]], 256, 256},
        --{[[Interface\AddOns\NorthernSkyRaidTools\Media\Memes\TherzBayern.blp]], 256, 24},
        -- {[[Interface\AddOns\NorthernSkyRaidTools\Media\Memes\senfisaur.blp]], 256, 256},
        --{[[Interface\AddOns\NorthernSkyRaidTools\Media\Memes\schinky.blp]], 256, 256},
        --{[[Interface\AddOns\NorthernSkyRaidTools\Media\Memes\TizaxHose.blp]], 202, 256},
        --{[[Interface\AddOns\NorthernSkyRaidTools\Media\Memes\ponkyBanane.blp]], 256, 174},
        --{[[Interface\AddOns\NorthernSkyRaidTools\Media\Memes\ponkyDespair.blp]], 256, 166},
        {[[Interface\AddOns\FysikMedia\Memes\dragane.png]], 256, 256},
        {[[Interface\AddOns\FysikMedia\Memes\getCoined.png]], 195, 211},
}