local _ = ... -- Internal namespace
local LSM = LibStub("LibSharedMedia-3.0")
FysikMedia = {}
LSM:Register("font","Expressway", [[Interface\Addons\NorthernSkyRaidTools\Media\Fonts\Expressway.TTF]])
--StatusBars
LSM:Register("statusbar","Atrocity", [[Interface\Addons\NorthernSkyRaidTools\Media\StatusBars\Atrocity]])
-- Open WA Options
function FysikMedia.OpenWA()
    print("hampusdid911")
end

-- Memes for Break-Timer
FysikMedia.BreakMemes = {
        {[[Interface\AddOns\FysikMedia\Memes\dragane.png]], 256, 256},
        {[[Interface\AddOns\FysikMedia\Memes\daitosus.png]], 256, 256},
        {[[Interface\AddOns\FysikMedia\Memes\draganepoop.png]], 256, 256},
        {[[Interface\AddOns\FysikMedia\Memes\guffyass.png]], 256, 256},
        {[[Interface\AddOns\FysikMedia\Memes\kazmilbeard.png]], 256, 256},
        {[[Interface\AddOns\FysikMedia\Memes\kazmilcat.png]], 256, 256},
        {[[Interface\AddOns\FysikMedia\Memes\kazmilcope.png]], 256, 256},
        {[[Interface\AddOns\FysikMedia\Memes\kazmilgirls.png]], 256, 256},
        {[[Interface\AddOns\FysikMedia\Memes\kazmiltitanic.png]], 256, 256},
        {[[Interface\AddOns\FysikMedia\Memes\kylgequest.png]], 256, 256},
}