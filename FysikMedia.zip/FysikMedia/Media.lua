local _ = ... -- Internal namespace
local LSM = LibStub("LibSharedMedia-3.0")
FysikMedia = {}
LSM:Register("font","Expressway", [[Interface\Addons\NorthernSkyRaidTools\Media\Fonts\Expressway.TTF]])
--StatusBars
LSM:Register("statusbar","Atrocity", [[Interface\Addons\NorthernSkyRaidTools\Media\StatusBars\Atrocity]])
-- Open WA Options
function FysikMedia.OpenWA()
    print("hampusdid911")
end

FysikMedia.BreakMemes = {
        {[[Interface\AddOns\FysikMedia\Memes\daitosus.png]], 268, 256},
        {[[Interface\AddOns\FysikMedia\Memes\draganeburger.png]], 249, 263},
        {[[Interface\AddOns\FysikMedia\Memes\draganecandy.png]], 249, 263},
        {[[Interface\AddOns\FysikMedia\Memes\draganehello.png]], 249, 263},
        {[[Interface\AddOns\FysikMedia\Memes\draganemarkus.png]], 249, 263},
        {[[Interface\AddOns\FysikMedia\Memes\draganepoop.png]], 249, 263},
        {[[Interface\AddOns\FysikMedia\Memes\draganetish.png]], 249, 263},
        {[[Interface\AddOns\FysikMedia\Memes\draganewtf.png]], 249, 263},
        {[[Interface\AddOns\FysikMedia\Memes\eggwa.png]], 184, 256},
        {[[Interface\AddOns\FysikMedia\Memes\fknlatoss.png]], 144, 256},
        {[[Interface\AddOns\FysikMedia\Memes\guffyass.png]], 191, 256},
        {[[Interface\AddOns\FysikMedia\Memes\kazandsheb.png]], 256, 68},
        {[[Interface\AddOns\FysikMedia\Memes\kazmilbeard.png]], 358, 256},
        {[[Interface\AddOns\FysikMedia\Memes\kazmilcat.png]], 301, 256},
        {[[Interface\AddOns\FysikMedia\Memes\kazmilcope.png]], 229, 256},
        {[[Interface\AddOns\FysikMedia\Memes\kazmildrunk.png]], 191, 256},
        {[[Interface\AddOns\FysikMedia\Memes\kazmilgirls.png]], 250, 256},
        {[[Interface\AddOns\FysikMedia\Memes\kazmiltitanic.png]], 256, 190},
        {[[Interface\AddOns\FysikMedia\Memes\kylgequest.png]], 256, 166},
        {[[Interface\AddOns\FysikMedia\Memes\whoraclemicdown.png]], 256, 166},
    }